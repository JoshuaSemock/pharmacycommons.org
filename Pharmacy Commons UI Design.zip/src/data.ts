export type EcoRisk = 'negligible' | 'low' | 'moderate' | 'high'
export type DPD = 'low' | 'moderate' | 'high'

export interface DrugFormulation {
  brand: string
  form: string
  strength: string
  manufacturer: string
  ndc?: string
}

export interface DrugInteraction {
  drug: string
  severity: 'minor' | 'moderate' | 'major'
  mechanism: string
}

export interface Drug {
  id: string
  name: string
  synonym?: string
  schedule: 'Rx' | 'OTC' | 'Controlled II' | 'Controlled III' | 'Controlled IV'
  therapeuticArea: string
  classification: {
    mechanism: string[]
    physiologicEffect: string[]
    chemicalClass: string
  }
  hierarchy: {
    ingredient: { name: string; cas: string; inchikey: string }
    saltForms: Array<{ name: string; cas: string }>
    formulations: DrugFormulation[]
  }
  clinical: {
    indications: string[]
    dosing: string
    halfLife: string
    proteinBinding: string
    metabolism: string
    bioavailability: string
    renalExcretion: string
    interactions: DrugInteraction[]
  }
  eco: {
    mec: number
    pec: number
    rq: number
    risk: EcoRisk
    dpd: DPD
    excretionRoute: string
    primaryConcern: string
    notes: string
  }
  description: string
}

export const DRUGS: Drug[] = [
  {
    id: 'metformin',
    name: 'Metformin',
    schedule: 'Rx',
    therapeuticArea: 'Endocrinology',
    description: 'First-line oral antidiabetic for type 2 diabetes mellitus. Reduces hepatic glucose production and improves insulin sensitivity without causing hypoglycemia.',
    classification: {
      mechanism: ['AMPK Activator', 'Hepatic Gluconeogenesis Inhibitor', 'Mitochondrial Complex I Inhibitor'],
      physiologicEffect: ['Decreased Blood Glucose', 'Improved Insulin Sensitivity', 'Reduced Hepatic Glucose Output'],
      chemicalClass: 'Biguanide',
    },
    hierarchy: {
      ingredient: { name: 'Metformin', cas: '657-24-9', inchikey: 'XZWYZXLIPXDOLR-UHFFFAOYSA-N' },
      saltForms: [
        { name: 'Metformin hydrochloride', cas: '1115-70-4' },
      ],
      formulations: [
        { brand: 'Glucophage', form: 'Tablet', strength: '500 mg, 850 mg, 1000 mg', manufacturer: 'Bristol-Myers Squibb' },
        { brand: 'Glucophage XR', form: 'Extended-release tablet', strength: '500 mg, 750 mg', manufacturer: 'Bristol-Myers Squibb' },
        { brand: 'Glumetza', form: 'Extended-release tablet', strength: '500 mg, 1000 mg', manufacturer: 'Bausch Health' },
        { brand: 'Fortamet', form: 'Extended-release tablet', strength: '500 mg, 1000 mg', manufacturer: 'Shionogi USA' },
        { brand: 'Riomet', form: 'Oral solution', strength: '500 mg/5 mL', manufacturer: 'Sun Pharma' },
      ],
    },
    clinical: {
      indications: ['Type 2 diabetes mellitus (first-line)', 'Prediabetes (off-label)', 'Polycystic ovary syndrome (off-label)', 'Weight management adjunct (off-label)'],
      dosing: 'Initial: 500 mg twice daily or 850 mg once daily with meals. Titrate by 500 mg weekly. Max: 2550 mg/day in divided doses.',
      halfLife: '4–9 hours (plasma); 17.6 hours (blood)',
      proteinBinding: 'Negligible',
      metabolism: 'Not metabolized. Excreted unchanged.',
      bioavailability: '50–60% (fasting state)',
      renalExcretion: '>90% unchanged via renal tubular secretion',
      interactions: [
        { drug: 'Iodinated contrast media', severity: 'major', mechanism: 'Temporary renal impairment increases risk of lactic acidosis' },
        { drug: 'Alcohol', severity: 'moderate', mechanism: 'Potentiates lactic acidosis risk; inhibits hepatic gluconeogenesis' },
        { drug: 'Cimetidine', severity: 'moderate', mechanism: 'Inhibits renal tubular secretion, increases metformin plasma levels by ~40%' },
        { drug: 'Carbonic anhydrase inhibitors', severity: 'moderate', mechanism: 'Increased risk of metabolic acidosis and lactic acidosis' },
      ],
    },
    eco: {
      mec: 0.04,
      pec: 2.1,
      rq: 52.5,
      risk: 'high',
      dpd: 'high',
      excretionRoute: 'Renal — excreted unchanged (>90%)',
      primaryConcern: 'Aquatic invertebrates and fish endocrine disruption; widespread contamination of surface water and groundwater',
      notes: 'Metformin is among the most frequently detected pharmaceuticals in global waterways. Its high water solubility, minimal protein binding, and lack of hepatic metabolism mean virtually all consumed drug enters wastewater. Guanylurea, a primary transformation product, is more persistent and detected at higher concentrations than the parent compound. Studies report intersex in fish at environmental concentrations.',
    },
  },
  {
    id: 'sertraline',
    name: 'Sertraline',
    schedule: 'Rx',
    therapeuticArea: 'Psychiatry',
    description: 'Selective serotonin reuptake inhibitor (SSRI) with broad-spectrum efficacy across mood and anxiety disorders. Most prescribed antidepressant globally by volume.',
    classification: {
      mechanism: ['Selective Serotonin Reuptake Inhibitor (SSRI)', 'Sigma-1 Receptor Agonist'],
      physiologicEffect: ['Increased Synaptic Serotonin', 'Anxiolytic Effect', 'Antidepressant Effect'],
      chemicalClass: 'Naphthalenamine',
    },
    hierarchy: {
      ingredient: { name: 'Sertraline', cas: '79617-96-2', inchikey: 'VGKDLMBJGBXTGI-SJCJKPOMSA-N' },
      saltForms: [
        { name: 'Sertraline hydrochloride', cas: '79559-97-0' },
      ],
      formulations: [
        { brand: 'Zoloft', form: 'Tablet', strength: '25 mg, 50 mg, 100 mg', manufacturer: 'Pfizer' },
        { brand: 'Zoloft', form: 'Oral concentrate', strength: '20 mg/mL', manufacturer: 'Pfizer' },
      ],
    },
    clinical: {
      indications: ['Major depressive disorder', 'Obsessive-compulsive disorder', 'Panic disorder', 'Post-traumatic stress disorder', 'Social anxiety disorder', 'Premenstrual dysphoric disorder'],
      dosing: 'MDD/OCD: Initial 50 mg/day. Range 50–200 mg/day. Panic/PTSD/SAD: Initial 25 mg/day, increase to 50 mg after 1 week.',
      halfLife: '26 hours (sertraline); 62–104 hours (N-desmethylsertraline)',
      proteinBinding: '98%',
      metabolism: 'Extensive hepatic metabolism via CYP2C19, CYP2C9, CYP2D6, CYP3A4',
      bioavailability: '44% (oral)',
      renalExcretion: '<0.2% unchanged in urine',
      interactions: [
        { drug: 'MAO inhibitors', severity: 'major', mechanism: 'Risk of serotonin syndrome; contraindicated within 14 days of MAOI use' },
        { drug: 'Linezolid', severity: 'major', mechanism: 'Monoamine oxidase inhibition increases serotonin syndrome risk' },
        { drug: 'Warfarin', severity: 'moderate', mechanism: 'Serotonin-mediated platelet inhibition increases bleeding risk; may alter warfarin levels' },
        { drug: 'Tramadol', severity: 'moderate', mechanism: 'Additive serotonergic effects; risk of serotonin syndrome and seizures' },
      ],
    },
    eco: {
      mec: 0.004,
      pec: 0.023,
      rq: 5.75,
      risk: 'moderate',
      dpd: 'moderate',
      excretionRoute: 'Hepatic metabolism → fecal/renal metabolites',
      primaryConcern: 'Detected in fish brain tissue at environmentally relevant concentrations; behavioral disruption in aquatic wildlife including reduced predator avoidance',
      notes: 'SSRIs enter aquatic systems primarily via wastewater effluent. While sertraline undergoes extensive metabolism, its high lipophilicity (logP ~5.0) promotes bioaccumulation in aquatic biota. Studies have detected sertraline and N-desmethylsertraline in the brains and livers of wild fish. Behavioral effects — including altered aggression, feeding, and anti-predator response — are documented at ng/L to μg/L concentrations.',
    },
  },
  {
    id: 'lisinopril',
    name: 'Lisinopril',
    schedule: 'Rx',
    therapeuticArea: 'Cardiology',
    description: 'Long-acting ACE inhibitor for hypertension, heart failure, and post-MI cardioprotection. Unlike most ACE inhibitors, lisinopril is not a prodrug.',
    classification: {
      mechanism: ['ACE Inhibitor', 'Renin-Angiotensin-Aldosterone System (RAAS) Inhibitor'],
      physiologicEffect: ['Decreased Blood Pressure', 'Reduced Preload and Afterload', 'Cardioprotective Effect', 'Renoprotective Effect'],
      chemicalClass: 'Lysine analog (non-prodrug ACE inhibitor)',
    },
    hierarchy: {
      ingredient: { name: 'Lisinopril', cas: '76547-98-3', inchikey: 'RLAWWYSOJDYHDC-BZSNNMDCSA-N' },
      saltForms: [
        { name: 'Lisinopril dihydrate', cas: '83915-83-7' },
      ],
      formulations: [
        { brand: 'Prinivil', form: 'Tablet', strength: '5 mg, 10 mg, 20 mg, 40 mg', manufacturer: 'Merck' },
        { brand: 'Zestril', form: 'Tablet', strength: '2.5 mg, 5 mg, 10 mg, 20 mg, 30 mg, 40 mg', manufacturer: 'AstraZeneca' },
        { brand: 'Qbrelis', form: 'Oral solution', strength: '1 mg/mL', manufacturer: 'Azurity Pharmaceuticals' },
      ],
    },
    clinical: {
      indications: ['Hypertension', 'Heart failure (adjunctive)', 'Acute MI (within 24 hours)', 'Diabetic nephropathy (off-label)'],
      dosing: 'HTN: Initial 10 mg/day; range 20–40 mg/day. HF: Initial 2.5–5 mg/day; target 20–40 mg/day. Post-MI: 5 mg within 24h, then titrate.',
      halfLife: '12 hours (effective); accumulation half-life up to 30 hours',
      proteinBinding: '0% (does not bind plasma proteins)',
      metabolism: 'Not metabolized',
      bioavailability: '25% (variable 6–60%)',
      renalExcretion: '100% unchanged',
      interactions: [
        { drug: 'Potassium-sparing diuretics', severity: 'moderate', mechanism: 'Additive hyperkalemia risk via RAAS blockade' },
        { drug: 'NSAIDs', severity: 'moderate', mechanism: 'Attenuate antihypertensive effect; increase nephrotoxicity risk' },
        { drug: 'Aliskiren (diabetic/renal patients)', severity: 'major', mechanism: 'Dual RAAS blockade; increased hypotension, hyperkalemia, renal impairment' },
        { drug: 'Sacubitril/valsartan', severity: 'major', mechanism: 'Risk of angioedema from combined NEP/ACE inhibition; contraindicated within 36 hours' },
      ],
    },
    eco: {
      mec: 0.10,
      pec: 0.001,
      rq: 0.01,
      risk: 'negligible',
      dpd: 'low',
      excretionRoute: 'Renal — excreted unchanged',
      primaryConcern: 'Negligible environmental risk at current detected concentrations',
      notes: 'Lisinopril is detected at very low concentrations in surface water (sub-ng/L range). Despite renal excretion unchanged, environmental concentrations remain far below predicted no-effect concentrations for aquatic organisms. Hydrolyzes under environmental conditions, further reducing persistence.',
    },
  },
  {
    id: 'amoxicillin',
    name: 'Amoxicillin',
    schedule: 'Rx',
    therapeuticArea: 'Infectious Disease',
    description: 'Broad-spectrum aminopenicillin antibiotic. First-line therapy for many community-acquired bacterial infections. Excellent oral bioavailability distinguishes it from ampicillin.',
    classification: {
      mechanism: ['Beta-lactam', 'Penicillin-binding Protein (PBP) Inhibitor', 'Cell Wall Synthesis Inhibitor'],
      physiologicEffect: ['Bactericidal Activity', 'Bacterial Cell Lysis', 'Inhibition of Transpeptidation'],
      chemicalClass: 'Aminopenicillin',
    },
    hierarchy: {
      ingredient: { name: 'Amoxicillin', cas: '26787-78-0', inchikey: 'LSQZJLSUYDQPKJ-NJBDSQKTSA-N' },
      saltForms: [
        { name: 'Amoxicillin trihydrate', cas: '61336-70-7' },
        { name: 'Amoxicillin sodium', cas: '34642-77-8' },
      ],
      formulations: [
        { brand: 'Amoxil', form: 'Capsule', strength: '250 mg, 500 mg', manufacturer: 'GSK' },
        { brand: 'Amoxil', form: 'Chewable tablet', strength: '125 mg, 250 mg', manufacturer: 'GSK' },
        { brand: 'Amoxil', form: 'Oral suspension', strength: '125 mg/5 mL, 250 mg/5 mL', manufacturer: 'GSK' },
        { brand: 'Augmentin', form: 'Tablet (combination)', strength: '500/125 mg, 875/125 mg (amox/clav)', manufacturer: 'GSK' },
      ],
    },
    clinical: {
      indications: ['Otitis media', 'Sinusitis', 'Pharyngitis (Group A Strep)', 'Community-acquired pneumonia', 'Urinary tract infections', 'H. pylori eradication (combination)'],
      dosing: 'Adults: 250–500 mg every 8h or 500–875 mg every 12h. Severe infections: 875 mg every 12h. Pediatric: 25–90 mg/kg/day divided.',
      halfLife: '1–1.5 hours',
      proteinBinding: '17–20%',
      metabolism: 'Minimal hepatic metabolism (~20%). Primarily excreted unchanged.',
      bioavailability: '74–92% (oral, food-independent)',
      renalExcretion: '60–80% unchanged via glomerular filtration and tubular secretion',
      interactions: [
        { drug: 'Warfarin', severity: 'moderate', mechanism: 'Alteration of gut flora reduces vitamin K production, may enhance anticoagulant effect' },
        { drug: 'Methotrexate', severity: 'moderate', mechanism: 'Competition for renal tubular secretion increases methotrexate toxicity risk' },
        { drug: 'Oral contraceptives', severity: 'minor', mechanism: 'Theoretical reduction in enterohepatic recycling of estrogens (clinical significance disputed)' },
        { drug: 'Probenecid', severity: 'minor', mechanism: 'Blocks renal tubular secretion, increases and prolongs amoxicillin levels' },
      ],
    },
    eco: {
      mec: 0.25,
      pec: 0.12,
      rq: 0.48,
      risk: 'low',
      dpd: 'low',
      excretionRoute: 'Renal (60–80% unchanged) + fecal',
      primaryConcern: 'Antimicrobial resistance selection pressure; promotes resistance gene dissemination in aquatic microbiomes even at sub-inhibitory concentrations',
      notes: 'Though the RQ for direct toxicity is low, amoxicillin and other beta-lactams pose an indirect ecological risk through antimicrobial resistance (AMR) promotion. Sub-inhibitory concentrations detected in waterways can drive horizontal gene transfer of resistance elements. Wastewater treatment plants remove 60–80% of amoxicillin, but activated sludge may itself become a resistance reservoir. Hydrolysis in water (t½ 1–7 days pH-dependent) limits persistence, but resistance genes persist far longer.',
    },
  },
  {
    id: 'atorvastatin',
    name: 'Atorvastatin',
    schedule: 'Rx',
    therapeuticArea: 'Cardiology',
    description: 'High-intensity HMG-CoA reductase inhibitor for dyslipidemia and cardiovascular risk reduction. Most prescribed statin worldwide, with robust cardiovascular outcomes data.',
    classification: {
      mechanism: ['HMG-CoA Reductase Inhibitor', 'Statin'],
      physiologicEffect: ['LDL Reduction (up to 60%)', 'HDL Elevation', 'Triglyceride Reduction', 'Plaque Stabilization', 'Anti-inflammatory Effect'],
      chemicalClass: 'Synthetic fluorophenyl-substituted pyrrole',
    },
    hierarchy: {
      ingredient: { name: 'Atorvastatin', cas: '134523-00-5', inchikey: 'XUKUURHRXDUEBC-KAYWLYCHSA-N' },
      saltForms: [
        { name: 'Atorvastatin calcium', cas: '134523-03-8' },
      ],
      formulations: [
        { brand: 'Lipitor', form: 'Tablet', strength: '10 mg, 20 mg, 40 mg, 80 mg', manufacturer: 'Pfizer' },
        { brand: 'Caduet', form: 'Tablet (combination)', strength: '5/10 to 10/80 mg (amlodipine/atorvastatin)', manufacturer: 'Pfizer' },
      ],
    },
    clinical: {
      indications: ['Primary hypercholesterolemia', 'Mixed dyslipidemia', 'Primary prevention of cardiovascular events (high-risk)', 'Secondary prevention post-ACS/MI', 'Familial hypercholesterolemia'],
      dosing: 'Initial: 10–20 mg/day. High-intensity: 40–80 mg/day. Evening dosing no longer required (long half-life of active metabolites).',
      halfLife: '14 hours (atorvastatin); 20–30 hours (active metabolites)',
      proteinBinding: '>98%',
      metabolism: 'Extensive hepatic first-pass via CYP3A4; active metabolites ortho- and parahydroxyatorvastatin',
      bioavailability: '12% (extensive first-pass)',
      renalExcretion: '<2% unchanged',
      interactions: [
        { drug: 'Strong CYP3A4 inhibitors (clarithromycin, itraconazole)', severity: 'major', mechanism: 'Markedly increased atorvastatin exposure; increased myopathy/rhabdomyolysis risk' },
        { drug: 'Gemfibrozil', severity: 'major', mechanism: 'Inhibition of glucuronidation and OATP1B1; significantly elevated statin levels' },
        { drug: 'Cyclosporine', severity: 'major', mechanism: 'OATP1B1 inhibition increases systemic exposure; cap at 10 mg/day' },
        { drug: 'Rifampin', severity: 'moderate', mechanism: 'CYP3A4 induction reduces atorvastatin levels significantly' },
      ],
    },
    eco: {
      mec: 0.010,
      pec: 0.003,
      rq: 0.30,
      risk: 'low',
      dpd: 'low',
      excretionRoute: 'Biliary/fecal (primarily as metabolites)',
      primaryConcern: 'Low detected environmental concentrations; potential endocrine signaling effects on aquatic organisms at higher loads',
      notes: 'Atorvastatin is extensively metabolized and excreted primarily via bile/feces, limiting direct renal input to aquatic systems. Detected concentrations in surface water are well below effect thresholds. Wastewater treatment is effective at removing statins. Ecotoxicological risk at current environmental concentrations is considered low, though cholesterol biosynthesis inhibition in aquatic invertebrates warrants continued monitoring.',
    },
  },
  {
    id: 'ibuprofen',
    name: 'Ibuprofen',
    schedule: 'OTC',
    therapeuticArea: 'Rheumatology / Analgesia',
    description: 'Non-selective COX-1 and COX-2 inhibitor with analgesic, anti-inflammatory, and antipyretic activity. Among the most widely used pharmaceuticals globally.',
    classification: {
      mechanism: ['Cyclooxygenase (COX-1/COX-2) Inhibitor', 'Prostaglandin Synthesis Inhibitor'],
      physiologicEffect: ['Analgesia', 'Anti-inflammatory Effect', 'Antipyresis', 'Platelet Aggregation Inhibition'],
      chemicalClass: 'Propionic acid NSAID',
    },
    hierarchy: {
      ingredient: { name: 'Ibuprofen', cas: '15687-27-1', inchikey: 'HEFNNWSXXWATRW-UHFFFAOYSA-N' },
      saltForms: [
        { name: 'Ibuprofen sodium', cas: '31121-93-4' },
        { name: 'Ibuprofen lysine', cas: '57469-77-9' },
        { name: 'Ibuprofen arginine', cas: '57775-29-8' },
      ],
      formulations: [
        { brand: 'Advil', form: 'Tablet', strength: '200 mg', manufacturer: 'Haleon' },
        { brand: 'Motrin IB', form: 'Tablet', strength: '200 mg', manufacturer: 'Johnson & Johnson' },
        { brand: 'Motrin', form: 'Oral suspension', strength: '100 mg/5 mL', manufacturer: 'Johnson & Johnson' },
        { brand: 'Caldolor', form: 'IV solution', strength: '100 mg/mL', manufacturer: 'Cumberland Pharmaceuticals' },
        { brand: 'NeoProfen', form: 'IV solution', strength: '17.1 mg/mL (ibuprofen lysine)', manufacturer: 'Recordati' },
      ],
    },
    clinical: {
      indications: ['Mild-to-moderate pain', 'Dysmenorrhea', 'Fever', 'Osteoarthritis', 'Rheumatoid arthritis', 'Patent ductus arteriosus (IV, neonatal)'],
      dosing: 'OTC analgesic/antipyretic: 200–400 mg every 4–6h (max 1200 mg/day). Rx anti-inflammatory: 400–800 mg every 6–8h (max 3200 mg/day).',
      halfLife: '1.8–2.5 hours',
      proteinBinding: '99%',
      metabolism: 'Hepatic via CYP2C9; inactive metabolites (hydroxy-, carboxy-ibuprofen)',
      bioavailability: '80–100% (oral)',
      renalExcretion: '45–60% as metabolites; <1% unchanged',
      interactions: [
        { drug: 'Aspirin (antiplatelet doses)', severity: 'moderate', mechanism: 'Competitive COX-1 binding may negate aspirin cardioprotection' },
        { drug: 'Lithium', severity: 'moderate', mechanism: 'Reduced renal lithium clearance; can increase lithium to toxic levels' },
        { drug: 'Methotrexate', severity: 'major', mechanism: 'Reduced renal elimination; elevated methotrexate toxicity risk' },
        { drug: 'ACE inhibitors/ARBs', severity: 'moderate', mechanism: 'Attenuates antihypertensive effect; risk of acute kidney injury' },
      ],
    },
    eco: {
      mec: 0.010,
      pec: 1.0,
      rq: 100,
      risk: 'high',
      dpd: 'moderate',
      excretionRoute: 'Renal (60–90% as metabolites)',
      primaryConcern: 'One of most frequently detected pharmaceuticals in global waterways; documented inhibition of prostaglandin synthesis in aquatic invertebrates and fish reproduction',
      notes: 'Ibuprofen is detected in rivers, lakes, and coastal waters globally at concentrations of 0.1–10 μg/L. Its OTC status and extremely high consumption volumes make it a priority aquatic contaminant. Conventional wastewater treatment removes 60–90% but fails at high-load events. Ibuprofen inhibits prostaglandin synthesis in aquatic organisms, affecting reproduction, osmoregulation, and stress responses. Photodegradation in surface water produces hydroxylated metabolites with similar bioactivity.',
    },
  },
]

export const CATEGORIES = [
  { id: 'mechanism', label: 'Mechanism of Action', count: 847, color: 'violet' as const },
  { id: 'effect', label: 'Physiologic Effect', count: 1203, color: 'aqua' as const },
  { id: 'chemical', label: 'Chemical Class', count: 312, color: 'sage' as const },
  { id: 'eco', label: 'Environmental Impact', count: 6, color: 'coral' as const },
]

export const ECO_RISK_COLORS: Record<EcoRisk, { bg: string; text: string; border: string; label: string }> = {
  negligible: { bg: 'bg-sage-100', text: 'text-sage-700', border: 'border-sage-300', label: 'Negligible' },
  low: { bg: 'bg-aqua-100', text: 'text-aqua-700', border: 'border-aqua-300', label: 'Low' },
  moderate: { bg: 'bg-amber-100', text: 'text-sage-800', border: 'border-amber-400', label: 'Moderate' },
  high: { bg: 'bg-coral-100', text: 'text-coral-600', border: 'border-coral-400', label: 'High' },
}
